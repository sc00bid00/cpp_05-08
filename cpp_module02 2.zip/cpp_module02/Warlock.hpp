/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Warlock.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:03:40 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 11:14:25 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

# include <string>
# include <iostream>
# include "ASpell.hpp"
# include "ATarget.hpp"
# include <map>
# include "SpellBook.hpp"

class Warlock{
	private:
		std::string	_name;
		std::string	_title;
		Warlock(void);
		Warlock(Warlock const& src);
		Warlock&	operator=(Warlock const& rhs);
		SpellBook	_spellBook;
		
	public:
		~Warlock(void);

		Warlock(std::string const& name, std::string const& title);

		std::string const&	getName(void) const;
		std::string const&	getTitle(void) const;

		void				setTitle(std::string const& title);

		void				introduce(void) const;

		void	learnSpell(ASpell* spell);
		void	forgetSpell(std::string spellName);
		void	launchSpell(std::string spellName, ATarget const& target);
};
