/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ATarget.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:29:09 by lsordo            #+#    #+#             */
/*   Updated: 2023/09/12 20:29:29 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ATarget.hpp"

ATarget::ATarget(void) {}

ATarget::ATarget(ATarget const& src) {
	*this = src;
}

ATarget::~ATarget(void) {}

ATarget&	ATarget::operator=(ATarget const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

ATarget::ATarget(std::string const& type) : _type(type) {}

std::string const&	ATarget::getType(void) const {
	return this->_type;
}

void	ATarget::getHitBySpell(ASpell const& spell) const {
	//<TYPE> has been <EFFECTS>!
	ASpell* testSpell;
	testSpell = NULL;
	if (&spell != testSpell)
		std::cout << this->_type << " has been " << spell.getEffects() << "!" << std::endl;
}


