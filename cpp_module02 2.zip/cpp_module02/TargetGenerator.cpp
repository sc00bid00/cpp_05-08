/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TargetGenerator.cpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:40:53 by lsordo            #+#    #+#             */
/*   Updated: 2023/09/12 19:13:03 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "TargetGenerator.hpp"

TargetGenerator::TargetGenerator(TargetGenerator const& src) {
	*this = src;
}

TargetGenerator&	TargetGenerator::operator=(TargetGenerator const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

TargetGenerator::TargetGenerator(void) {}

TargetGenerator::~TargetGenerator(void) {
	for(std::map<std::string, ATarget*>::iterator iTarget = this->_targets.begin();iTarget != this->_targets.end(); ++iTarget)
		delete iTarget->second;
	this->_targets.clear();
}

void	TargetGenerator::learnTargetType(ATarget* target) {
	if(target) {
		std::map<std::string, ATarget*>::iterator iTarget = this->_targets.find(target->getType());
		if(iTarget == this->_targets.end())
			this->_targets[target->getType()] = target->clone();
	}
}

void	TargetGenerator::forgetTargetType(std::string const& type) {
	std::map<std::string, ATarget*>::iterator iTarget = this->_targets.find(type);
	if(iTarget != this->_targets.end())
	{
		delete iTarget->second;
		this->_targets.erase(iTarget);
	}
}

ATarget*	TargetGenerator::createTarget(std::string const& type) {
	std::map<std::string, ATarget*>::iterator iTarget = this->_targets.find(type);
	if(iTarget != this->_targets.end())
		return iTarget->second;
	return NULL;
}
