/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dummy.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:47:35 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 09:50:47 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Dummy.hpp"

//"Target Practice Dummy"

Dummy::Dummy(void) : ATarget("Target Practice Dummy") {}

Dummy::Dummy(Dummy const& src) : ATarget(src.getType()) {
	*this = src;
}

Dummy::~Dummy(void) {}

Dummy&	Dummy::operator=(Dummy const& rhs) {
	if (this != &rhs)
		*this = rhs;
	return *this;
}

Dummy*	Dummy::clone(void) const {
	return (new(Dummy));
}
