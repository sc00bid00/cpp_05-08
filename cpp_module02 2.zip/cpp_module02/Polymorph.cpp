/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Polymorph.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:18:39 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:19:47 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Polymorph.hpp"

//set the name to "Polymorph" and the effects to "fwooshed"

Polymorph::Polymorph(void) :ASpell("Polymorph","turned into a critter") {}

Polymorph::Polymorph(Polymorph const& src) : ASpell(src.getName(), src.getEffects()) {
	*this = src;
}

Polymorph::~Polymorph(void) {}

Polymorph&	Polymorph::operator=(Polymorph const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

Polymorph*	Polymorph::clone(void) const {
	return (new(Polymorph));
}
