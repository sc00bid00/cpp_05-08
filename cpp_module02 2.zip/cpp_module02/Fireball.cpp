/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fireball.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:18:36 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:19:19 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fireball.hpp"

//set the name to "Fireball" and the effects to "fwooshed"

Fireball::Fireball(void) :ASpell("Fireball","burnt to a crisp") {}

Fireball::Fireball(Fireball const& src) : ASpell(src.getName(), src.getEffects()) {
	*this = src;
}

Fireball::~Fireball(void) {}

Fireball&	Fireball::operator=(Fireball const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

Fireball*	Fireball::clone(void) const {
	return (new(Fireball));
}
