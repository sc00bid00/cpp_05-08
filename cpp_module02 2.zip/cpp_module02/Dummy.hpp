/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dummy.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:45:42 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:03:58 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include "ATarget.hpp"

class Dummy : public ATarget {
	public:
		Dummy(void);
		Dummy(Dummy const& src);
		~Dummy(void);
		Dummy&	operator=(Dummy const& rhs);

		Dummy*	clone(void) const;
};
