/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ASpell.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:19:01 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 09:38:58 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

# include <string>
# include <iostream>
# include "ATarget.hpp"

class ATarget;

class ASpell {
	protected:
		std::string	_name;
		std::string	_effects;

	public:
		ASpell(void);
		ASpell(ASpell const& src);
		virtual ~ASpell(void);
		ASpell&	operator=(ASpell const& rhs);

		ASpell(std::string const& name, std::string const& effects);

		std::string const&	getName(void) const;
		std::string const&	getEffects(void) const;

		virtual	ASpell*	clone(void) const = 0;

		void	launch(ATarget const& target);
};
