/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SpellBook.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:22:16 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:27:25 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include <map>
# include <string>
# include "ASpell.hpp"

class SpellBook {
	private:
		SpellBook(SpellBook const& src);
		SpellBook&	operator=(SpellBook const& rhs);
		std::map<std::string,ASpell*>	_spells;

	public:
		SpellBook(void);
		~SpellBook(void);

		void	learnSpell(ASpell* spell);
		void	forgetSpell(std::string const& spellName);
		ASpell*	createSpell(std::string const& spellName);
};
