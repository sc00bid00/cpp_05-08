/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fwoosh.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:38:37 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 09:45:39 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include "ASpell.hpp"

class Fwoosh : public ASpell {
	public:
		Fwoosh(void);
		Fwoosh(Fwoosh const& src);
		~Fwoosh(void);
		Fwoosh&	operator=(Fwoosh const& rhs);

		Fwoosh*	clone(void) const;
};
