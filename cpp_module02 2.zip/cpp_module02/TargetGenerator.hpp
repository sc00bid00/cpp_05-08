/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TargetGenerator.hpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:37:21 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:43:32 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include <map>
# include <string>
# include "ATarget.hpp"

class TargetGenerator {
	private:
		TargetGenerator(TargetGenerator const& src);
		TargetGenerator&	operator=(TargetGenerator const& rhs);
		std::map<std::string, ATarget*>	_targets;

	public:
		TargetGenerator(void);
		~TargetGenerator(void);
		void		learnTargetType(ATarget* target);
		void		forgetTargetType(std::string const&	type);
		ATarget*	createTarget(std::string const& type);
};
