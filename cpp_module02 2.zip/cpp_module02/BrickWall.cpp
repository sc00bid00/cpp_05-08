/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BrickWall.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:21:02 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:21:43 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "BrickWall.hpp"

//"Target Practice BrickWall"

BrickWall::BrickWall(void) : ATarget("Inconspicuous Red-brick Wall") {}

BrickWall::BrickWall(BrickWall const& src) : ATarget(src.getType()) {
	*this = src;
}

BrickWall::~BrickWall(void) {}

BrickWall&	BrickWall::operator=(BrickWall const& rhs) {
	if (this != &rhs)
		*this = rhs;
	return *this;
}

BrickWall*	BrickWall::clone(void) const {
	return (new(BrickWall));
}
