/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ATarget.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:25:08 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 09:39:02 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

# include <string>
# include <iostream>
# include "ASpell.hpp"

class ASpell;

class ATarget {
	private:
		std::string	_type;
	public:
		ATarget(void);
		ATarget(ATarget const& src);
		virtual ~ATarget(void);
		ATarget&	operator=(ATarget const& rhs);

		ATarget(std::string const& type);

		std::string const&	getType(void) const;

		virtual	ATarget*	clone(void) const = 0;

		void	getHitBySpell(ASpell const& spell) const;
};
