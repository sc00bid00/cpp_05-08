/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fwoosh.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:41:06 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:04:19 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fwoosh.hpp"

//set the name to "Fwoosh" and the effects to "fwooshed"

Fwoosh::Fwoosh(void) :ASpell("Fwoosh","fwooshed") {}

Fwoosh::Fwoosh(Fwoosh const& src) : ASpell(src.getName(), src.getEffects()) {
	*this = src;
}

Fwoosh::~Fwoosh(void) {}

Fwoosh&	Fwoosh::operator=(Fwoosh const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

Fwoosh*	Fwoosh::clone(void) const {
	return (new(Fwoosh));
}
