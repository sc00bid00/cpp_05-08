/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SpellBook.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:26:04 by lsordo            #+#    #+#             */
/*   Updated: 2023/09/12 19:57:07 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "SpellBook.hpp"

SpellBook::SpellBook(SpellBook const& src) {
	*this = src;
}

SpellBook&	SpellBook::operator=(SpellBook const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

SpellBook::SpellBook(void) {}

SpellBook::~SpellBook(void) {
	for(std::map<std::string, ASpell*>::iterator iSpell = this->_spells.begin(); iSpell != this->_spells.end();++iSpell)
		delete iSpell->second;
	this->_spells.clear();
}

void	SpellBook::learnSpell(ASpell* spell) {
	if(spell) {
		std::map<std::string, ASpell*>::iterator iSpell = this->_spells.find(spell->getName());
		if(iSpell == this->_spells.end())
			this->_spells[spell->getName()] = spell->clone();
	}
}

void	SpellBook::forgetSpell(std::string const& spellName) {
	std::map<std::string, ASpell*>::iterator iSpell = this->_spells.find(spellName);
	if(iSpell != this->_spells.end()) {
		delete iSpell->second;
		this->_spells.erase(iSpell);
	}
}

ASpell*	SpellBook::createSpell(std::string const& spellName) {
	std::map<std::string, ASpell*>::iterator iSpell = this->_spells.find(spellName);
	if(iSpell != this->_spells.end())
		return iSpell->second;
	return NULL;
}
