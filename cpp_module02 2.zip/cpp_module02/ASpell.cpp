/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ASpell.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:22:36 by lsordo            #+#    #+#             */
/*   Updated: 2023/09/12 20:13:52 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ASpell.hpp"

ASpell::ASpell(void) {}

ASpell::ASpell(ASpell const& src) {
	*this = src;
}

ASpell::~ASpell(void) {}

ASpell&	ASpell::operator=(ASpell const& rhs) {
	if (this != &rhs)
		*this = rhs;
	return *this;
}

ASpell::ASpell(std::string const& name, std::string const& effects) : _name(name), _effects(effects) {}

std::string const&	ASpell::getName(void) const {
	return this->_name;
}

std::string const&	ASpell::getEffects(void) const {
	return this->_effects;
}

void	ASpell::launch(ATarget const& target) {
	/* if target is a NULL pointer then *this segfaults
	a reference cannot be bound to a NULL pointer per definition
	therefore flags would not allow compiling &target != NULL in the if claus to protect
	we have to circumvent with the test variable */
	ATarget* test;
	test = NULL;
	if(&target != test)
		target.getHitBySpell(*this);
}
