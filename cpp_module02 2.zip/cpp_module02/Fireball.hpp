/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fireball.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:17:20 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:17:42 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include "ASpell.hpp"

class Fireball : public ASpell {
	public:
		Fireball(void);
		Fireball(Fireball const& src);
		~Fireball(void);
		Fireball&	operator=(Fireball const& rhs);

		Fireball*	clone(void) const;
};
