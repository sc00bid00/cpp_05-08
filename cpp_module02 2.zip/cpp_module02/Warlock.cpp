/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Warlock.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:07:41 by lsordo            #+#    #+#             */
/*   Updated: 2023/09/12 20:16:37 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Warlock.hpp"
#define H std::cerr << "DEBUG HERE" << std::endl;

Warlock::Warlock(void) {}

Warlock::Warlock(Warlock const& src) {
	*this = src;
}

Warlock&	Warlock::operator=(Warlock const& rhs) {
	if(this != &rhs)
		*this = rhs;
	return *this;
}

Warlock::~Warlock(void) {
	// <NAME>: My job here is done!
	std::cout << this->_name << ": My job here is done!" << std::endl;
}

Warlock::Warlock(std::string const& name, std::string const& title) : _name(name), _title(title) {
	//<NAME>: This looks like another boring day.
	std::cout << this->_name << ": This looks like another boring day." << std::endl;
}

std::string const&	Warlock::getName(void) const {
	return this->_name;
}

std::string const&	Warlock::getTitle(void) const {
	return this->_title;
}

void				Warlock::setTitle(std::string const& title) {
	this->_title = title;
}

void	Warlock::introduce(void) const {
	// <NAME>: I am <NAME>, <TITLE>!
	std::cout << this->_name << ": I am " << this->_name << ", " << this->_title << "!" << std::endl;
}

void	Warlock::learnSpell(ASpell* spell) {
		this->_spellBook.learnSpell(spell);
}

void	Warlock::forgetSpell(std::string spellName) {
	this->_spellBook.forgetSpell(spellName);
}

void	Warlock::launchSpell(std::string spellName, ATarget const& target) {
	if(this->_spellBook.createSpell(spellName))
		this->_spellBook.createSpell(spellName)->launch(target);
	}


