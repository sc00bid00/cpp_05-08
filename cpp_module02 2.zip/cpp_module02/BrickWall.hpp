/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BrickWall.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:20:13 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:20:42 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include "ATarget.hpp"

class BrickWall : public ATarget {
	public:
		BrickWall(void);
		BrickWall(BrickWall const& src);
		~BrickWall(void);
		BrickWall&	operator=(BrickWall const& rhs);

		BrickWall*	clone(void) const;
};
