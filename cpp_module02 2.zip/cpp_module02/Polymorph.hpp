/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Polymorph.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lsordo <lsordo@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 10:17:25 by lsordo            #+#    #+#             */
/*   Updated: 2023/08/17 10:17:58 by lsordo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
# include "ASpell.hpp"

class Polymorph : public ASpell {
	public:
		Polymorph(void);
		Polymorph(Polymorph const& src);
		~Polymorph(void);
		Polymorph&	operator=(Polymorph const& rhs);

		Polymorph*	clone(void) const;
};
